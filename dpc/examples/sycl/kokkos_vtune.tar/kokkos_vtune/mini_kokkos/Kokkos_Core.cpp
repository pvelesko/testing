#include "Kokkos_Core.hpp"

cl::sycl::queue q;
cl::sycl::device dev;
cl::sycl::context ctx;
int _max_threads;
