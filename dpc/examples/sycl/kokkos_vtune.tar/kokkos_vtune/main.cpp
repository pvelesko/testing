#include <CL/sycl.hpp>
#include "Util.hpp"
#include <stdlib.h>
#include <iostream>
#include "mini_kokkos/Kokkos_Core.hpp"
using namespace cl::sycl;
int main(int argc, char** argv) {
  process_args(argc, argv);
  Kokkos::initialize();
  {
  Kokkos::View<float*> x("x", n);
  dump(x.data(), "x");
  auto lam = [=](const int i) {
    x(i) = 1;
  };
  Kokkos::RangePolicy<Kokkos::HostSpace> rangepol(0, n);
  Kokkos::parallel_for("test", Kokkos::Experimental::require(rangepol, 0), lam);
  q.wait_and_throw();
  dump(x.data(), "x");
  }
  Kokkos::finalize();
  return 0;
}
